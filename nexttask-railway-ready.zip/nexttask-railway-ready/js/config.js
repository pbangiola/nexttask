// --- Deployment Configuration ---
// Replace this value with the public domain shown in your Railway service.
// Example: https://nexttask-production.up.railway.app
const RAILWAY_API_BASE_URL = 'https://REPLACE-WITH-YOUR-RAILWAY-DOMAIN.up.railway.app';

// Local development can continue using the Express server on port 3000.
const API_BASE_URL = (() => {
    const hostname = window.location.hostname;
    const isLocal = hostname === 'localhost' || hostname === '127.0.0.1';

    if (isLocal) {
        return window.location.port === '3000'
            ? window.location.origin
            : 'http://localhost:3000';
    }

    return RAILWAY_API_BASE_URL.replace(/\/$/, '');
})();

function getApiUrl(path) {
    const normalizedPath = path.startsWith('/') ? path : `/${path}`;
    return `${API_BASE_URL}${normalizedPath}`;
}

function isRailwayApiConfigured() {
    return !API_BASE_URL.includes('REPLACE-WITH-YOUR-RAILWAY-DOMAIN');
}
