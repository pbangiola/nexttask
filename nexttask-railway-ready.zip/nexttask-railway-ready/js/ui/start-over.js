let currentSortRawTasks = [];

function showStartOverBtn() {
    document.getElementById('startOverBtn')?.classList.remove('hidden');
}

function hideStartOverBtn() {
    document.getElementById('startOverBtn')?.classList.add('hidden');
}

// Shows a three-option overlay: restart just the current step, restart the
// whole session, or cancel and return to whatever was on screen.
function showStartOverPrompt() {
    if (document.getElementById('startOverModal')) return; // already open

    const overlay = document.createElement('div');
    overlay.id = 'startOverModal';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0,0,0,0.4)';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'center';
    overlay.style.justifyContent = 'center';
    overlay.style.zIndex = '1000';

    const box = document.createElement('div');
    box.style.backgroundColor = '#fff';
    box.style.padding = '20px';
    box.style.borderRadius = '8px';
    box.style.maxWidth = '320px';
    box.style.width = '85%';
    box.style.textAlign = 'center';

    const msg = document.createElement('p');
    msg.textContent = 'What would you like to do?';
    msg.style.fontWeight = 'bold';
    box.appendChild(msg);

    const restartStepBtn = document.createElement('button');
    restartStepBtn.textContent = 'Restart This Step';
    restartStepBtn.style.display = 'block';
    restartStepBtn.style.width = '100%';
    restartStepBtn.style.margin = '8px 0';
    restartStepBtn.addEventListener('click', () => {
        overlay.remove();
        restartCurrentScreen();
    });
    box.appendChild(restartStepBtn);

    const restartAllBtn = document.createElement('button');
    restartAllBtn.textContent = 'Restart From the Beginning';
    restartAllBtn.style.display = 'block';
    restartAllBtn.style.width = '100%';
    restartAllBtn.style.margin = '8px 0';
    restartAllBtn.addEventListener('click', async () => {
        overlay.remove();
        await clearSession();
        window.location.reload();
    });
    box.appendChild(restartAllBtn);

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.style.display = 'block';
    cancelBtn.style.width = '100%';
    cancelBtn.style.margin = '8px 0';
    cancelBtn.style.backgroundColor = '#eceff1';
    cancelBtn.addEventListener('click', () => {
        overlay.remove();
    });
    box.appendChild(cancelBtn);

    overlay.appendChild(box);
    document.body.appendChild(overlay);
}

// Resets just the current step, without wiping the whole session
function restartCurrentScreen() {
    if (!document.getElementById('timeConstraintInput').classList.contains('hidden')) {
        document.getElementById('availableTime').value = '';
        document.getElementById('endConstraint').value = '';

    } else if (!document.getElementById('taskInput').classList.contains('hidden')) {
        document.getElementById('tasks').value = '';
        document.getElementById('skipSortCheckbox').checked = false;
        checkTaskInputCapacity();

    } else if (!document.getElementById('taskCompare').classList.contains('hidden')) {
        // Mid-sorting: drop the in-progress sort, return to task entry with the list preserved
        sortedTasks = [];
        currentTaskIndex = 0;
        document.getElementById('dynamicContainer').innerHTML = '';
        document.getElementById('taskCompare').classList.add('hidden');
        document.getElementById('tasks').value = currentSortRawTasks.join('\n');
        document.getElementById('taskInput').classList.remove('hidden');
        checkTaskInputCapacity();

    } else if (document.getElementById('timingGatewayScreen')) {
        // Nothing entered yet on this screen - just re-render it
        promptForUpfrontTimings();

    } else if (document.getElementById('timingEntryScreen')) {
        // Mid-estimating: clear any estimates entered so far, restart from the first task
        for (let i = 1; i < sortedTasks.length; i++) {
            sortedTasks[i].estimatedTime = 0;
        }
        runSequentialTimingInput(1);
    }
    // mode-select / work-choice screens have nothing to reset

    saveSession();
}

