// --- App Initialization & Event Handlers ---
function initApp() {
    document.getElementById('csvUpload')?.addEventListener('change', handleCSVUpload);
    document.getElementById('stopWorkingBtn')?.addEventListener('click', handleStopWorking);
    document.getElementById('tasks')?.addEventListener('input', checkTaskInputCapacity);

    document.getElementById('startOverBtn')?.addEventListener('click', showStartOverPrompt);

    document.getElementById('workBtn')?.addEventListener('click', () => {
        sessionStartTimestamp = Date.now();
        document.getElementById('modeSelect').classList.add('hidden');
        document.getElementById('workChoiceStep').classList.remove('hidden');
        showStartOverBtn();
        saveSession();
    });

    document.getElementById('createNewListBtn')?.addEventListener('click', () => {
        document.getElementById('workChoiceStep').classList.add('hidden');
        document.getElementById('timeConstraintInput').classList.remove('hidden');
        showStartOverBtn();
        saveSession();
    });

    document.getElementById('resumeExistingListBtn')?.addEventListener('click', async () => {
        const queue = await fetchExistingQueue();

        if (queue.length === 0) {
            alert("There's no saved list to resume yet — let's start a new one.");
            return;
        }

        sortedTasks = queue.map(q => ({
            name: q.task_name,
            estimatedTime: q.estimated_minutes || 0,
            actualTimeMs: q.elapsed_ms || 0,
            timestamps: { created: Date.now(), started: null, completed: null }
        }));
        currentTaskIndex = 0;

        document.getElementById('workChoiceStep').classList.add('hidden');
        hideStartOverBtn();
        saveSession();

        // No sorting, no questions - go straight into the first task.
        startDeadlineSetting();
    });

    document.getElementById('timeConstraintNextBtn')?.addEventListener('click', () => {
        const timeVal = parseInt(document.getElementById('availableTime').value, 10);
        const constraintVal = document.getElementById('endConstraint').value.trim();

        if (!timeVal || timeVal <= 0) {
            alert("How many minutes do you have? Enter a number to continue.");
            return;
        }

        totalAvailableTime = timeVal;
        endConstraint = constraintVal;

        document.getElementById('timeConstraintInput').classList.add('hidden');
        
        const taskInputContainer = document.getElementById('taskInput');
        taskInputContainer.classList.remove('hidden');
        checkTaskInputCapacity();
        showStartOverBtn();
        saveSession();
    });

    document.getElementById('startSort')?.addEventListener('click', () => {
        const taskInput = document.getElementById('tasks').value.trim();
        if (!taskInput) {
            alert('Add at least one task to get started.');
            return;
        }

        let rawTasks = taskInput.split('\n').map(t => t.trim()).filter(t => t);
        rawTasks = [...new Set(rawTasks)];

        const skipSort = document.getElementById('skipSortCheckbox').checked;

        document.getElementById('taskInput').classList.add('hidden');

        if (skipSort || rawTasks.length <= 1) {
            sortedTasks = rawTasks.map(name => ({ 
                name, 
                estimatedTime: 0, 
                actualTimeMs: 0,
                timestamps: { created: Date.now(), started: null, completed: null } 
            }));
            currentTaskIndex = 0;
            saveSession();
            syncPendingQueueToBackend();
            promptForUpfrontTimings();
        } else {
            currentSortRawTasks = rawTasks;
            sortStartTime = Math.floor(Date.now() / 1000);
            startMergeSort(rawTasks);
        }
    });

    loadSession();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

