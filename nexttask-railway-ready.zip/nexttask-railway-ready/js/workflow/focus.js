// Live Execution Focus Panel
function startFocusScreen() {
    document.getElementById('stopWorkingBtn').classList.remove('hidden');

    const container = document.getElementById('dynamicContainer');
    container.innerHTML = '';

    const currentTask = sortedTasks[currentTaskIndex];
    if (!currentTask) {
        displaySortedTasks();
        return;
    }

    const focusScreen = document.createElement('div');
    focusScreen.id = 'focusScreen';

    const taskName = document.createElement('h2');
    taskName.textContent = `Current Task: ${currentTask.name}`;
    focusScreen.appendChild(taskName);

    const timerDisplay = document.createElement('p');
    timerDisplay.id = 'timer';
    timerDisplay.style.fontSize = '24px';
    timerDisplay.style.fontWeight = 'bold';
    focusScreen.appendChild(timerDisplay);

    let deadlinePromptShown = false;
    let completionStarted = false;

    function recordElapsedTime() {
        const nowMs = Date.now();
        const lastStarted = currentTask.timestamps?.lastStarted || (taskStartTimestamp * 1000);
        const actualElapsedMs = Math.max(0, nowMs - lastStarted);
        currentTask.actualTimeMs = (currentTask.actualTimeMs || 0) + actualElapsedMs;

        if (!currentTask.timestamps) currentTask.timestamps = {};
        currentTask.timestamps.lastStarted = nowMs;

        return nowMs;
    }

    function finalizeCurrentTaskAndAdvance() {
        if (completionStarted) return;
        completionStarted = true;
        clearInterval(timerInterval);

        const nowMs = recordElapsedTime();
        currentTask.timestamps.completed = nowMs;

        const timeDifference = deadline - Math.floor(nowMs / 1000);
        spareTime += timeDifference;

        logTaskCompletionToBackend(currentTask);
        removeTaskFromQueue(currentTask.name);

        pausedSecondsRemaining = 0;
        currentTaskIndex++;

        if (currentTaskIndex < sortedTasks.length) {
            startDeadlineSetting();
        } else {
            document.getElementById('stopWorkingBtn').classList.add('hidden');
            displaySpareTime();
        }
    }

    function closeDeadlinePrompt() {
        document.getElementById('deadlineExpiredModal')?.remove();
    }

    function moveBlockedTaskToBack(blockerName) {
        clearInterval(timerInterval);
        closeDeadlinePrompt();

        recordElapsedTime();
        pausedSecondsRemaining = 0;
        deadline = 0;

        const blockedTask = sortedTasks.splice(currentTaskIndex, 1)[0];
        blockedTask.timestamps.lastStarted = null;

        const blockerTask = {
            name: blockerName,
            estimatedTime: 0,
            actualTimeMs: 0,
            timestamps: {
                created: Date.now(),
                started: null,
                lastStarted: null,
                completed: null
            }
        };

        // The blocker must be handled before the task it is blocking.
        sortedTasks.push(blockerTask, blockedTask);
        syncPendingQueueToBackend();
        saveSession();
        startDeadlineSetting();
    }

    function showDeadlineExpiredPrompt() {
        if (deadlinePromptShown || document.getElementById('deadlineExpiredModal')) return;
        deadlinePromptShown = true;

        const overlay = document.createElement('div');
        overlay.id = 'deadlineExpiredModal';
        overlay.style.position = 'fixed';
        overlay.style.inset = '0';
        overlay.style.backgroundColor = 'rgba(0,0,0,0.45)';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.zIndex = '1000';

        const box = document.createElement('div');
        box.style.backgroundColor = '#fff';
        box.style.padding = '20px';
        box.style.borderRadius = '8px';
        box.style.maxWidth = '360px';
        box.style.width = '85%';
        box.style.textAlign = 'center';

        const heading = document.createElement('h3');
        heading.textContent = "Time's up";
        box.appendChild(heading);

        const message = document.createElement('p');
        message.textContent = `Keep working on “${currentTask.name},” or mark it blocked.`;
        box.appendChild(message);

        const continueBtn = document.createElement('button');
        continueBtn.textContent = 'Continue Working';
        continueBtn.style.display = 'block';
        continueBtn.style.width = '100%';
        continueBtn.style.margin = '8px 0';
        continueBtn.addEventListener('click', closeDeadlinePrompt);
        box.appendChild(continueBtn);

        const blockedBtn = document.createElement('button');
        blockedBtn.textContent = 'Blocked';
        blockedBtn.style.display = 'block';
        blockedBtn.style.width = '100%';
        blockedBtn.style.margin = '8px 0';
        blockedBtn.addEventListener('click', () => {
            const blockerName = window.prompt('What task is blocking this one?')?.trim();
            if (!blockerName) return;
            moveBlockedTaskToBack(blockerName);
        });
        box.appendChild(blockedBtn);

        overlay.appendChild(box);
        document.body.appendChild(overlay);
    }

    function updateTimer() {
        const nowSec = Math.floor(Date.now() / 1000);
        const timeRemaining = deadline - nowSec;

        timerDisplay.style.color = timeRemaining >= 0 ? 'green' : 'red';

        const absTime = Math.abs(timeRemaining);
        const minutes = Math.floor(absTime / 60);
        const seconds = absTime % 60;
        timerDisplay.textContent = `Time Remaining: ${timeRemaining >= 0 ? '' : '-'}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        if (timeRemaining <= 0) {
            showDeadlineExpiredPrompt();
        }
    }

    updateTimer();
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(updateTimer, 1000);

    const doneNext = document.createElement('button');
    doneNext.textContent = 'Done, Next!';
    doneNext.addEventListener('click', finalizeCurrentTaskAndAdvance);
    focusScreen.appendChild(doneNext);

    const addTask = document.createElement('button');
    addTask.textContent = 'Add New Task';
    addTask.addEventListener('click', () => {
        clearInterval(timerInterval);
        closeDeadlinePrompt();

        const nowMs = recordElapsedTime();
        const nowSec = Math.floor(nowMs / 1000);

        // Save the remaining timer state for seamless resumption. Negative
        // values are preserved so overtime remains visible after returning.
        pausedSecondsRemaining = deadline - nowSec;

        startAddTask();
    });
    focusScreen.appendChild(addTask);

    container.appendChild(focusScreen);
    saveSession();
}
