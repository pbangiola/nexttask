// --- Config ---
const MAX_TASK_MINUTES = 20;

// Holds the raw (pre-sort) task names so a mid-sort "restart this screen" can recover them
let currentSortRawTasks = [];

// --- Session ID & Initialization ---
let sessionId = localStorage.getItem('taskSorterSessionId');
if (!sessionId) {
    sessionId = 'session_' + Math.random().toString(36).substring(2, 9);
    localStorage.setItem('taskSorterSessionId', sessionId);
}

let sortedTasks = []; // Array: { name, estimatedTime, actualTimeMs, timestamps: {} }
let currentTaskIndex = 0;
let timerInterval = null;
let deadline = 0;
let spareTime = 0; 
let taskStartTimestamp = 0; 
let pausedSecondsRemaining = 0; 

// Track overall session constraints
let totalAvailableTime = 0;
let endConstraint = "";

// Global tracking timestamps (saved in state, hidden from UI)
let sessionStartTimestamp = null;
let currentStepStartTimestamp = null;
let sortStartTime = 0;
